﻿//Author: Yasiru Karunawansa
//Purpose: holds the safe radius for an obstacle.
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : MonoBehaviour {
    public float radius;
	// Use this for initialization
	void Start () {
        radius = 10f;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
